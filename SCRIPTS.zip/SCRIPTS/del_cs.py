import sys
import numpy as np
import pprint
from random import randint


def random():
    a1 = open("res_selected.txt", "r").readlines()
    outfile = open("res_randomized.txt", "w")
    outfile3 = open("res_randomized3.txt", "w")
    frac = 0.50
    frac3= 0.50
    rest=[]
    rest3 =[]
    res=[]
    out = []
    out3 = []
    for a in a1:
        res.extend(a.split())
    print res
    while len(rest) < int(frac*float(len(res))):
        indice = randint(0, len(res) - 1)
        if res[indice] not in rest:
            rest.append(res[indice])
            out.append(str(res[indice]) + "\n")
    outfile.writelines(out)
    print rest

    while len(rest3) < int(frac3*float(len(res))):
        indice = randint(0, len(res) - 1)
        if res[indice] not in rest and res[indice] not in rest3:
            rest3.append(res[indice])
            out3.append(str(res[indice]) + "\n")
    outfile3.writelines(out3)
    print rest3

def delcs():
    a1 = open("res_randomized.txt", "r").readlines()
    a2 = open("res_randomized3.txt", "r").readlines()
    a3 = open("R_session/predicted_cs.txt", "r").readlines()
    outfile1 = open("new_cs1.txt", "w")
    outfile2 = open("new_cs2.txt", "w")
#    seqfile = open("new_sequence.txt", "w")
    out1=[]
    out2=[]
    seq=[]
    todel1=[]
    todel2=[]
    for a in a1:
        todel1.append(a[0:4].strip())
        todel2.append(a[0:4].strip())
    for a in a2:
        todel2.append(a[0:4].strip())
    print todel1
    print todel2
    for i in a3:
        if i.split("\t")[1].strip() not in todel1:
            out1.append(i)
        if i.split("\t")[1].strip() not in todel2:
            out2.append(i)

    outfile1.writelines(out1)
    outfile2.writelines(out2)

random()
delcs()
