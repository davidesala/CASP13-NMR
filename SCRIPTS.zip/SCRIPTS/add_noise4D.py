import sys
import numpy as np
import re
import pprint
from random import randint


def noise():
    a1 = open(sys.argv[1], "r").readlines()
    outfileCCH = open("noiseCCH.txt", "w")
    outfileNNH = open("noiseNNH.txt", "w")
    outfileCNH = open("noiseCNH.txt", "w")
    outfileNCH = open("noiseNCH.txt", "w")
    outfileC= open("noiseC.txt", "w")
    outfileN= open("noiseN.txt", "w")
    outNNH = []
    outCCH = []
    outCNH = []
    outNCH = []
    outC = []
    outN = []
    coppie = []
    tup=()
    delta = 0.03
    frac=0.015
    index=[]
    assigned = []
    usable = []
    cs=[]
    indprev = []

    for a in a1:
        index.append(int(a[0:4]))
        assigned.append(a)
        cs.append(float(a[19:27]))
        indprev.append(-1)
        if (a[14:18].strip() == "H" or ((
                (a[9:12].strip() == "ILE" and (a[14:17].strip() == "HD")) or (
                a[9:12].strip() == "LEU" and a[14:18].strip() == "HD1") or (
                a[9:12].strip() == "LEU" and a[14:18].strip() == "HD2") or (
                a[9:12].strip() == "VAL" and a[14:18].strip() == "HG1") or (
                a[9:12].strip() == "VAL" and a[14:18].strip() == "HG2") or (
                a[9:12].strip() == "ALA" and a[14:18].strip() == "HB") or (
                a[9:12].strip() == "GLN" and a[14:16].strip() == "HE") or (
                a[9:12].strip() == "ASN" and a[14:16].strip() == "HD")))):
            usable.append(True)
        else:
            usable.append(False)

    for a in assigned:
        if usable[assigned.index(a)]:
            if a[14:18].strip() == "H":
                stri1 = a[5:17] + "N"
            if a[9:12].strip() == "ALA" and a[14:18].strip() == "HB":
                stri1 = a[5:16] + "CB"
            if a[9:12].strip() == "ILE" and a[14:17].strip() == "HD":
                stri1 = a[5:15] + "CD"
            # if a[9:12].strip() == "ILE" and a[14:18].strip() == "HG2":
            #     stri1 = a[5:15] + "CG2"
            if a[9:12].strip() == "LEU" and a[14:18].strip() == "HD1":
                stri1 = a[5:15] + "CD1"
            if a[9:12].strip() == "LEU" and a[14:18].strip() == "HD2":
                stri1 = a[5:15] + "CD2"
            if a[9:12].strip() == "VAL" and a[14:18].strip() == "HG1":
                stri1 = a[5:15] + "CG1"
            if a[9:12].strip() == "VAL" and a[14:18].strip() == "HG2":
                stri1 = a[5:15] + "CG2"
            for l in assigned:
                if stri1 in l:
                    ind_stri1 = assigned.index(l)  # NB this is the index in the CS file minus 1 !
                    break
            indprev[assigned.index(a)] = ind_stri1

#    for j in range(int(frac*float(len(index)))):
    while len(coppie) < int(frac*float(len(index))):
        puppa1 = randint(0, len(index)-1)
        puppa2 = puppa1
        while puppa2 == puppa1:
            puppa2  = randint(0, len(index)-1)
        if puppa1 < puppa2:
           tup = (puppa1, puppa2)
        else:
            tup = (puppa2, puppa1)
            if usable[puppa1-1] and usable[puppa2-1]:
                if tup not in coppie:
                    coppie.append(tup)

    for j1, j2 in coppie:
        if cs[j1-1] > 5 and cs[j2-1] > 5:   # hNNH
            print ('\t'.join(["%.8f"%(cs[j1-1]), str(cs[j2-1]), str(cs[indprev[j1-1]]), str(666.666)]))
            outNNH.append('\t'.join(["%.14f"%(cs[j1-1]), "%.14f"%(cs[j2-1]), "%.14f"%(cs[indprev[j1-1]]), "%.14f"%(666.666)]) + " thisisalabel \n")
        elif cs[j1-1] <= 5 and cs[j2-1] <= 5: #hCCH
            print ('\t'.join([str(cs[j1 - 1]), str(cs[j2 - 1]), str(cs[indprev[j1 - 1]]), str(555.555)]))
            outCCH.append('\t'.join(["%.14f"%(cs[j1 - 1]), "%.14f"%(cs[j2 - 1]), "%.14f"%(cs[indprev[j1 - 1]]), "%.14f"%(555.555)]) + " thisisalabel \n")
        elif cs[j1-1] <= 5 and cs[j2-1] > 5: #hCCH
            print ('\t'.join([str(cs[j1 - 1]), str(cs[j2 - 1]), str(cs[indprev[j1 - 1]]), str(555.666)]))
            outCNH.append('\t'.join(["%.14f"%(cs[j1 - 1]), "%.14f"%(cs[j2 - 1]), "%.14f"%(cs[indprev[j1 - 1]]), "%.14f"%(555.666)]) + " thisisalabel \n")
        elif cs[j1-1] > 5 and cs[j2-1] <= 5: #hNCH
            print ('\t'.join([str(cs[j1 - 1]), str(cs[j2 - 1]), str(cs[indprev[j1 - 1]]), str(666.555)]))
            outNCH.append('\t'.join(["%.14f"%(cs[j1 - 1]), "%.14f"%(cs[j2 - 1]), "%.14f"%(cs[indprev[j1 - 1]]), "%.14f"%(666.555)]) + " thisisalabel \n")
        elif cs[j1 - 1] > 5:  # HN
            print ('\t'.join(["%.8f" % (cs[j1 - 1]), str(cs[j2 - 1]), str(cs[indprev[j1 - 1]]), str(111.111)]))
            outN.append('\t'.join(["%.14f" % (cs[j1 - 1]), "%.14f" % (cs[j2 - 1]), "%.14f" % (cs[indprev[j1 - 1]]),
                                   "%.14f" % (111.111)]) + " thisisalabel \n")
        else: #CH
            print ('\t'.join([str(cs[j1 - 1]), str(cs[j2 - 1]), str(cs[indprev[j1 - 1]]), str(222.222)]))
            outC.append('\t'.join(["%.14f" % (cs[j1 - 1]), "%.14f" % (cs[j2 - 1]), "%.14f" % (cs[indprev[j1 - 1]]),
                                   "%.14f" % (222.222)]) + " thisisalabel \n")
    outfileNNH.writelines(outNNH)
    outfileCCH.writelines(outCCH)
    outfileCNH.writelines(outCNH)
    outfileNCH.writelines(outNCH)
    outfileN.writelines(outN)
    outfileC.writelines(outC)
noise()