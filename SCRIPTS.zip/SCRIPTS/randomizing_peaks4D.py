import sys
import os
import numpy as np
import re
import pprint
from random import randint

def randpeaks():
    a1 = open(sys.argv[1], "r").readlines()
    a2 = open(sys.argv[2], "r").readlines()
    a3 = open(sys.argv[3], "r").readlines()
    a4 = open(sys.argv[4], "r").readlines()
    a5 = open(sys.argv[5], "r").readlines()
    a6 = open(sys.argv[6], "r").readlines()
    outfileCCH = open("ranpeaksCCH.txt", "w")
    outfileNNH = open("ranpeaksNNH.txt", "w")
    outfileCNH = open("ranpeaksCNH.txt", "w")
    outfileNCH = open("ranpeaksNCH.txt", "w")
    outfileC = open("ranpeaksC.txt", "w")
    outfileN = open("ranpeaksN.txt", "w")
    outN = []
    outC = []
    outNNH = []
    outCCH = []
    outCNH = []
    outNCH = []
    while a1:
        j = randint(0, len(a1)-1)
        outCCH.append(a1[j])
        del a1[j]
    outfileCCH.writelines(outCCH)
    while a2:
        j = randint(0, len(a2) - 1)
        outNNH.append(a2[j])
        del a2[j]
    outfileNNH.writelines(outNNH)
    while a3:
        j = randint(0, len(a3) - 1)
        outCNH.append(a3[j])
        del a3[j]
    outfileCNH.writelines(outCNH)
    while a4:
        j = randint(0, len(a4) - 1)
        outNCH.append(a4[j])
        del a4[j]
    outfileNCH.writelines(outNCH)
    while a5:
        j = randint(0, len(a5)-1)
        outC.append(a5[j])
        del a5[j]
    outfileC.writelines(outC)
    while a6:
        j = randint(0, len(a6) - 1)
        outN.append(a6[j])
        del a6[j]
    outfileN.writelines(outN)

randpeaks()