import sys
import os
import numpy as np
import re
import pprint
from random import randint

def formatting():
    a1 = open("new_ambi3.txt", "r").readlines()
    a2 = open("noise.txt", "r").readlines()
    outfile = open("new_ambi4.txt", "w")
    block=[]
    dizBL = {}
    count=0
    NB=True
    randlist=[]
    out=[]
    for i in a1+a2:
        if i[0:4].strip():
            block.append(i[0:29].strip())
            NB=True
        else:
            if NB:
                count=count+1
                NB=False
                dizBL[count]=block
                block = []
    if NB:
        count=count+1
        dizBL[count]=block
        block = []

    i = 0
    while i < count:
        c = randint(1,count)
        if c not in randlist:
            randlist.append(c)
            i += 1


    print count
    print(randlist)
    print len(randlist)
    print count in randlist
#    print dizBL.keys()

    i = 0
    tmp = []
    for j in randlist:
        i += 1
        if i!= 1:
            out.append("\n")
        for k in dizBL[j]:
            tmp = k.split()
            if len(tmp)==5:
                tmp[4] = str(i)
            else:
                tmp.append(str(i))
            out.append('\t'.join(tmp)+"\n")
#            out.append(k[:20] + " " + str(i) + "\n")

    outfile.writelines(out)

#os.system("awk -v OFS='\t' '{print $1, $2, $3, $4, $5}' new_ambi4_TOFORMAT.txt > new_ambi4.txt")

formatting()
