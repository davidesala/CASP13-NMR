import sys
import numpy as np
import pprint

a1 = open("hh_temp.txt", "r").readlines()
outfile=open("input_suoi.txt","w")
pres=[]
out=[]
count=0

for i in a1:
    if int(i.split()[4]) not in pres:
        pres.append(int(i.split()[4]))
        out.append("\n"+i)
        count+=1
#        print (i+"\n")
    else:
        out.append(i)
#        print (i)
outfile.writelines(out)
print(count)