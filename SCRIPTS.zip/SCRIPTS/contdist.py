import sys, pprint
import numpy as np
def parsing():
    out = []
    outfile=open("gremlinMON.out","w")
    a1 = open("contacts.txt", "r").readlines()
    a2 = open("distances.txt", "r").readlines()
    for i in a1:
        for a in a2:
            if a[0:10].strip() == i[0:10].strip() and float(a[11:17].strip()) < 10:
                pprint.pprint(str(a[0:10].strip()))
                out.append(str(i[0:20].strip())+ " " + str(a[11:17].strip()) + "\n")
#                print (str(i[0:20].strip())+ " " + str(a[12:17].strip()) + "\n")
    outfile.writelines(out)
parsing()