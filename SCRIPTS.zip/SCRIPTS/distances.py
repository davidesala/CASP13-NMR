import sys
import numpy as np
def distance():
    out = []
    outfile=open(sys.argv[2],"w")
    a1 = open(sys.argv[1], "r").readlines()
    for i in a1:
        if i[12:16].strip() == "H":
            for a in a1:
                if a[12:16].strip() == "H".
                    ix=float(i[30:38])
                    iy=float(i[38:46])
                    iz=float(i[46:54])
                    ax=float(a[30:38])
                    ay=float(a[38:46])
                    az=float(a[46:54])
                    dist=np.sqrt((ix-ax)**2 + (iy-ay)**2 + (iz - az)**2)
                    if dist > 0 and dist <=6 :
                        out.append(a[22:27] + " " + i[22:27] + " " + str(dist) + " " + a[12:16] + " " + i[12:16]+"\n")
    outfile.writelines(out)
distance()