import sys
import numpy as np
import re
import pprint
from random import randint as r

def random():
    a1 = open("res_selected.txt", "r").readlines()
    outfile = open("res_randomized.txt", "w")
    frac = 0.25
    rest=[]
    res=[]
    out = []
    for a in a1:
        res.extend(a.split())
    print res
    g = (r(0, len(res) - 1) for _ in xrange(int(len(res) * (1-frac))))
    for b in g:
        rest.append(res[b])
        del res[b]
    temp3 = [item for item in res if item not in rest]
    print temp3
    for c in temp3:
        out.append(str(c) + "" + "\n")
    outfile.writelines(out)

def search():
    a1 = open("res_randomized.txt", "r").readlines()
    a2 = open("input_suoi.txt", "r").readlines()
    outfile = open("picks2purge.txt", "w")
    out=[]
    for i in a1:
        for a in a2:
            if i[0:3].strip() == a[0:3].strip() or i[0:3].strip() == a[6:9].strip():
                #print a[0:29].strip()
                out.append(a[0:29] + "\n")
    outfile.writelines(out)

def purge(): #to remove assignments containing the missed residues
    a1 = open("picks2purge.txt", "r").readlines()
    a2 = open("input_suoi.txt", "r").readlines()
    outfile = open("new_ambi.txt", "w")
    out=[]
    for a in a2:
            if a not in a1:
                #print a
                out.append(a[0:29] + "\n")
    outfile.writelines(out)


def parsing():
    out = []
    miss= []
    missfile=open("new_missing.txt","w")
    outfile=open("new_presents.txt","w")
    a1 = open("new_ambi.txt", "r").readlines()
    a2 = open("input_miei.txt", "r").readlines()
    N=1
    P=1
    found = 0
    NBprev=0
    NB=0
    for i in a1:
        if i[0:3].strip():
            NB = i[24:28]
            NBprev = 0
            for a in a2:
                if i[0:3].strip() == a[0:3].strip() and i[6:9].strip() == a[6:9].strip() and i[12:15].strip() == a[12:15].strip() and i[18:21].strip() == a[18:21].strip():
                    if N==P:
                        out.append(i[0:3] + " " + i[6:9] + " " +i[12:15] + " " + i[18:21] + " " + i[24:28] +"\n" )
                        N=P+1
                        found=1
        else:
            if found==0 and NBprev==0 and NB!=0:
                pprint.pprint(NB)
                miss.append(str(NB) + "\n")
            N=P
            NBprev = 1
            found = 0
    outfile.writelines(out)
    missfile.writelines(miss)


def purge2():    #to remove peaks due to the missed residues in the 3D structure
    a1 = open("new_missing.txt", "r").readlines() #check the last peak of the file
    a2 = open("new_ambi.txt", "r").readlines()
    outfile = open("new_ambi2.txt", "w")
    out=[]
    b = map(lambda s:s.strip("\n").strip(), a1)
    print b
    for a in a2:
        if a[24:29].strip() not in b:
            out.append(a[0:29] + "\n")
    outfile.writelines(out)

#random()
search()
purge()
parsing()
purge2()
