import sys
import numpy as np
import re
import pprint
from random import randint as r

def random():
    a1 = open("res_selected.txt", "r").readlines()
    a2 = open("res_randomized.txt", "r").readlines()
    outfile = open("res_randomized3.txt", "w")
    frac = 0.10
    rest=[]
    res=[]
    check=[]
    out = []
    for a in a1:
        res.extend(a.split())
    for i in a2:
	    check.extend(i.split())
#    print check

    g = (r(0, len(res) - 1) for _ in xrange(int(len(res) * (1-frac))))
    for b in g:
        rest.append(res[b])
        del res[b]
    temp3 = [item for item in res if item not in rest and item not in check]
    print temp3

    for c in temp3:
        out.append(str(c) + "" + "\n")
    outfile.writelines(out)

def search():
    a1 = open("res_randomized3.txt", "r").readlines()
    a2 = open("new_ambi2.txt", "r").readlines()
    outfile = open("assig2purge.txt", "w")
    out=[]
    for i in a1:
        for a in a2:
            if i[0:3].strip() == a[0:3].strip() or i[0:3].strip() == a[6:9].strip():
                #print a[0:29].strip()
                out.append(a[0:29] + "\n")
    outfile.writelines(out)

def purge(): #to remove assignments containing the missed residues
    a1 = open("assig2purge.txt", "r").readlines()
    a2 = open("new_ambi2.txt", "r").readlines()
    outfile = open("new_ambi3.txt", "w")
    out=[]
    for a in a2:
            if a not in a1:
                #print a
                out.append(a[0:29] + "\n")
    outfile.writelines(out)


def parsing():
    out = []
    miss= []
    missfile=open("new_missing3.txt","w")
    outfile=open("new_presents3.txt","w")
    a1 = open("new_ambi3.txt", "r").readlines()
    a2 = open("input_miei.txt", "r").readlines()
    N=1
    P=1
    found = 0
    NBprev=0
    NB=0
    NBline = []
    for i in a1:
        if i[0:3].strip():
            NB = i[24:28]
            NBline.append(i)
	    NBprev = 0
            for a in a2:
                if i[0:3].strip() == a[0:3].strip() and i[6:9].strip() == a[6:9].strip() and i[12:15].strip() == a[12:15].strip() and i[18:21].strip() == a[18:21].strip():
                    if N==P:
                        out.append(i[0:3] + " " + i[6:9] + " " +i[12:15] + " " + i[18:21] + " " + i[24:28] +"\n" )
                        N=P+1
                        found=1
        else:
            if found==0 and NBprev==0 and NB!=0:
                pprint.pprint(NB)
                miss.append("\n")
                for jj in NBline:
                    miss.append(jj)
            N=P
            NBprev = 1
            found = 0
            NBline = []
    outfile.writelines(out)
    missfile.writelines(miss)

random()
search()
purge()
parsing()

