import sys,pprint
import numpy as np
def distance():
    out = []
    outfile=open("distances_dimer.out","w")
    a1 = open("AC.pdb", "r").readlines()
    for i in a1:
        for a in a1:
            if (a[12:16].strip() == "CA" and i[12:16].strip() == "CA") and (a[21:22].strip() == "A" and i[21:22].strip() == "C"):
                ix=float(i[30:38])
                iy=float(i[38:46])
                iz=float(i[46:54])
                ax=float(a[30:38])
                ay=float(a[38:46])
                az=float(a[46:54])
                dist=np.sqrt((ix-ax)**2 + (iy-ay)**2 + (iz - az)**2)
                if a[22:27] != i[22:27]:
                    out.append(str(a[22:27].strip()) + " " + str(i[22:27].strip()) + " " + str("%.1f"%(dist)) + "\n")
                    #print (([a[22:27], i[22:27],  str(dist)]) + "\n")
    outfile.writelines(out)
distance()