import sys
import numpy as np
import pprint

def casp(fileIN):
    out = []
    outfile = open("contacts.out", "w")
    dizAllH={}
    dizRES={}
    RES = []
    resNum=0
    first = True
    input_pdb = open(fileIN, "r").readlines()
    for i in input_pdb:
        if i[0:4] == "ATOM":

            if first:
                resCheck = int(i[22:26].strip())
                first = False

            resNum = int(i[22:26].strip())
            if resNum != resCheck:
                dizRES[resCheck]=RES
                resCheck = resNum
                RES =[]
            if resNum == resCheck:
                RES.append(i[0:54])
    dizRES[resCheck] = RES

#    pprint.pprint(dizRES)

    for i in dizRES:
        dizH={}
        resAccepted=["ILE","VAL","ALA","LEU","GLN","ASN"]
        for a in dizRES[i]:
            if a[17:20].strip() in resAccepted:

                if "HD1" in a[12:16].strip() and len(a[12:16].strip()) == 4 :
                    if "HD1" not in dizH.keys():
                        dizH["HD1"] = []
                    dizH["HD1"].append(a[30:54])

                elif "HD2" in a[12:16].strip() and len(a[12:16].strip()) == 4 :
                    if "HD2" not in dizH.keys():
                        dizH["HD2"] = []
                    dizH["HD2"].append(a[30:54])

                elif "HG1" in a[12:16].strip() and len(a[12:16].strip()) == 4 :
                    if "HG1" not in dizH.keys():
                        dizH["HG1"] = []
                    dizH["HG1"].append(a[30:54])

                elif "HG2" in a[12:16].strip() and len(a[12:16].strip()) == 4 :
                    if "HG2" not in dizH.keys():
                        dizH["HG2"] = []
                    dizH["HG2"].append(a[30:54])

                elif "HB" in a[12:16].strip() and a[17:20].strip() == "ALA" :
                    if "HB" not in dizH.keys():
                        dizH["HB"] = []
                    dizH["HB"].append(a[30:54])

                elif "HE21" in a[12:16].strip() and a[17:20].strip() == "GLN" :
                    if "HE21" not in dizH.keys():
                        dizH["HE21"] = []
                    dizH["HE21"].append(a[30:54])

                elif "HE22" in a[12:16].strip() and a[17:20].strip() == "GLN":
                    if "HE22" not in dizH.keys():
                        dizH["HE22"] = []
                    dizH["HE22"].append(a[30:54])

                elif "HD22" in a[12:16].strip() and a[17:20].strip() == "ASN" :
                    if "HD22" not in dizH.keys():
                        dizH["HD22"] = []
                    dizH["HD22"].append(a[30:54])

                elif "HD21" in a[12:16].strip() and a[17:20].strip() == "ASN":
                    if "HD21" not in dizH.keys():
                        dizH["HD21"] = []
                    dizH["HD21"].append(a[30:54])

                if  a[17:20].strip() == "VAL" and ("HG" in a[12:16].strip() and len(a[12:16].strip()) == 4 ) :
                    if "QG" not in dizH.keys():
                        dizH["QG"] = []
                    dizH["QG"].append(a[30:54])

                elif  a[17:20].strip() == "LEU" and ("HD" in a[12:16].strip() and len(a[12:16].strip()) == 4 ) :
                    if "QD" not in dizH.keys():
                        dizH["QD"] = []
                    dizH["QD"].append(a[30:54])


            if a[12:16].strip() == "H":
                tmp = []
                tmp.append(a[30:54])
                dizH["H"] = tmp

        if len(dizH) > 0:
            dizAllH[i]={}
            dizAllH[i]["ResName"] = a[17:20].strip()
            dizAllH[i]["Hydrogens"] = dizH

    #pprint.pprint(dizAllH)

    for i in dizAllH:
        #print "####"
        #pprint.pprint(dizAllH[i])
        #pprint.pprint(dizAllH[i]["Hydrogens"])
#        pprint.pprint(dizAllH[i]["Hydrogens"]["H"])


        for a in dizAllH:
            DatomsHi = dizAllH[i]["Hydrogens"]
            DatomsHa = dizAllH[a]["Hydrogens"]
            for atomsHi in DatomsHi:
                for atomsHa in DatomsHa:
                    dist =[]
                    for j in DatomsHi[atomsHi]:
                        jx = float(j.split()[0])
                        jy = float(j.split()[1])
                        jz = float(j.split()[2])
                        for k in DatomsHa[atomsHa]:
                            kx = float(k.split()[0])
                            ky = float(k.split()[1])
                            kz = float(k.split()[2])
                            dist.append(np.sqrt((jx-kx)**2+(jy-ky)**2+(jz-kz)**2))
                    dist6 = 0
                    dist6Finale=0
                    for d in dist:
                        if d>0:
                            dist6 = dist6 + d**(-6)
                            dist6Finale = dist6**(-(1./6))
                    if ( i != a and dist6Finale > 0 and dist6Finale <= 5) or (i == a  and atomsHi != atomsHa and dist6Finale > 0 and dist6Finale <= 5):
                            print i, a, atomsHi, atomsHa, dist6Finale
                            out.append(str(i) + " " + str(a) + " " + str(atomsHi) + " " + str(atomsHa) + " " + str(
                            dist6Finale) + "\n")
    outfile.writelines(out)

if __name__== "__main__":
  casp(sys.argv[1])
