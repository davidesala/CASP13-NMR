import sys
import numpy as np
import pprint
from random import randint


def remove():
c
    a2= open("res_randomized3.txt", "r").readlines()
    a3 = open("H0980_DIHEDTOT.txt", "r").readlines()
 #   a4 = open("T0980s1_RDCTOT.txt", "r").readlines()
    outdih = open("H0980_DIHED.txt", "w")
 #   outrdc = open("T0980s1_RDC.txt", "w")
    res=[]
    dih=[]
  #  rdc=[]
    for a in a1+a2:
        res.extend(a.split())
    print res
    for j in a3:
        if j.split()[1] not in res:
            dih.append(j)
  #  for j in a4:
  #      if j.split()[0] not in res:
  #          rdc.append(j)
    outdih.writelines(dih)
  #  outrdc.writelines(rdc)

remove()