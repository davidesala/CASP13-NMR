import sys
import numpy as np
import pprint

def renumb():
    a1 = open("N1008_temp.pdb", "r").readlines()
    res=[]

    for i in range(1,len(a1)):
        b= int(a1[i].split()[5])
        if b > 17:
            print b-17
    print a1




renumb()
