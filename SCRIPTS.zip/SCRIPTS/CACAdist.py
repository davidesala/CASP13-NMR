import sys
import numpy as np
def distance():
    out = []
    outfile=open(sys.argv[2],"w")
    a1 = open(sys.argv[1], "r").readlines()
    for i in a1:
        if i[12:16].strip() == "CA":
            for a in a1:
                if a[12:16].strip() == "CA":
                    ix=float(i[30:38])
                    iy=float(i[38:46])
                    iz=float(i[46:54])
                    ax=float(a[30:38])
                    ay=float(a[38:46])
                    az=float(a[46:54])
                    dist=np.sqrt((ix-ax)**2 + (iy-ay)**2 + (iz - az)**2)
                    if a[22:27] != i[22:27]:
                        out.append('\t'.join([a[22:27] , i[22:27] ,  "%.1f"%(dist)]) + "\n")
#                        print ('\t'.join([a[22:27], i[22:27],  str(dist)]) + "\n")
    outfile.writelines(out)
distance()