import sys
import numpy as np
import pprint

def parsing():
    out = []
    miss= []
    missfile=open("new_missing3.txt","w")
    outfile=open("new_presents3.txt","w")
    a1 = open("input_suoi.txt", "r").readlines()
    a2 = open("input_miei.txt", "r").readlines()
    count=0
    N=1
    P=1
    found = 0
    NBprev=0
    NB=0
    NBline = []
    for i in a1:
        if i[0:3].strip():
            NB = i[24:28]
            NBline.append(i)
	    NBprev = 0
            for a in a2:
                if i[0:3].strip() == a[0:3].strip() and i[6:9].strip() == a[6:9].strip() and i[12:15].strip() == a[12:15].strip() and i[18:21].strip() == a[18:21].strip():
                    if N==P:
                        out.append(i[0:3] + " " + i[6:9] + " " +i[12:15] + " " + i[18:21] + " " + i[24:28] +"\n" )
                        N=P+1
                        found=1
        else:
            if found==0 and NBprev==0 and NB!=0:
                count=count+1
                pprint.pprint(NB)
                miss.append("\n")
                for jj in NBline:
                    miss.append(jj)
            N=P
            NBprev = 1
            found = 0
            NBline = []
    print count
    outfile.writelines(out)
    missfile.writelines(miss)

parsing()
