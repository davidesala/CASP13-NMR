import sys
import numpy as np
def parsing():
    out = []
    outfile=open(sys.argv[2],"w")
    a1 = open(sys.argv[1], "r").readlines()
    a2 = open(sys.argv[3], "r").readlines()
    N=1
    for i in a1:
        if i[0:3].strip():
            for a in a2:
                if i[0:3].strip() == a[0:5].strip():
                    out.append(str(ix) + " " +str(ax) + " " + str(N)+  "\n")
        else:
            N = N + 1
            out.append("\n")
    outfile.writelines(out)
parsing()