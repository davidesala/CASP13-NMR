import sys
import numpy as np
def distance():
    out = []
    outfile=open(sys.argv[2],"w")
    a1 = open(sys.argv[1], "r").readlines()
    for i in a1:
        if i[13:16].strip() == "H" or (((i[17:20].strip() == "ILE" and (i[13:15].strip() == "HD" or i[13:15].strip() == "HG")) or (i[17:20].strip() == "LEU" and i[13:15].strip() == "HD") or (i[17:20].strip() == "VAL" and i[13:15].strip() == "HG") or (i[17:20].strip() =="ALA" and i[13:15].strip() == "HB") or (i[17:20].strip() =="GLN" and i[13:15].strip() == "HE") or (i[17:20].strip() =="ASN" and i[13:15].strip() == "HD"))):
            for a in a1:
                if a[13:16].strip() == "H" or (((a[17:20].strip() == "ILE" and (a[13:15].strip() == "HD" or a[13:15].strip() == "HG")) or (a[17:20].strip() == "LEU" and a[13:15].strip() == "HD") or (a[17:20].strip() == "VAL" and a[13:15].strip() == "HG") or (a[17:20].strip() =="ALA" and a[13:15].strip() == "HB") or (a[17:20].strip() =="GLN" and a[13:15].strip() == "HE") or (a[17:20].strip() =="ASN" and a[13:15].strip() == "HD"))):
                    ix=float(i[30:38])
                    iy=float(i[38:46])
                    iz=float(i[46:54])
                    ax=float(a[30:38])
                    ay=float(a[38:46])
                    az=float(a[46:54])
                    dist=np.sqrt((ix-ax)**2 + (iy-ay)**2 + (iz - az)**2)
                    if dist > 0 and dist <=5 :
                        out.append(a[24:26] + " " + i[24:26] + " " + str(dist) + " " + a[13:16] + " " + i[13:16]+"\n")
                    else:
                        if dist >5 and dist <= 6 and (a[13:16].strip() == "H" and i[13:16].strip() == "H"):
                            out.append(a[24:26] + " " + i[24:26] + " " + str(dist) + " " + a[13:16] + " " + i[13:16]+"\n")
    outfile.writelines(out)
distance()