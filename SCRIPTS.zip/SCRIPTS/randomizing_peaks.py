import sys
import os
import numpy as np
import re
import pprint
from random import randint

def randpeaks():
    a1 = open(sys.argv[1], "r").readlines()
    a2 = open(sys.argv[2], "r").readlines()
    outfileC = open("ranpeaksC.txt", "w")
    outfileN = open("ranpeaksN.txt", "w")
    outN = []
    outC = []

    while a1:
        j = randint(0, len(a1)-1)
        outC.append(a1[j])
        del a1[j]
    outfileC.writelines(outC)
    while a2:
        j = randint(0, len(a2) - 1)
        outN.append(a2[j])
        del a2[j]
    outfileN.writelines(outN)


randpeaks()